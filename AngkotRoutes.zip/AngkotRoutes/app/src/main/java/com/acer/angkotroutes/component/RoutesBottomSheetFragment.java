package com.acer.angkotroutes.component;


import android.os.Bundle;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.acer.angkotroutes.util.Angkot;
import com.acer.angkotroutes.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class RoutesBottomSheetFragment extends Fragment {


    public RoutesBottomSheetFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(final LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        LinearLayout linearLayout = (LinearLayout) inflater.inflate(
                R.layout.fragment_routes_bottom_sheet,
                container,
                false
        );

        RecyclerView recyclerView = (RecyclerView) linearLayout.findViewById(R.id.recycler_view_bottom_sheet);

        AngkotRoutesAdapter adapter = new AngkotRoutesAdapter(Angkot.texts);
        recyclerView.setAdapter(adapter);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        adapter.setListener(new AngkotRoutesAdapter.Listener() {
            @Override
            public void onClick(int position) {
                int pos = position + 1;
                CharSequence sequence = "Card " + pos + " Clicked";
                Snackbar snackbar = Snackbar.make(
                        getActivity().findViewById(R.id.coordinator_layout),
                        sequence,
                        Snackbar.LENGTH_SHORT
                );
                CoordinatorLayout.LayoutParams layoutParams = (CoordinatorLayout.LayoutParams) snackbar.getView().getLayoutParams();
                layoutParams.setAnchorId(R.id.view_bottom_navigation);
                layoutParams.anchorGravity = Gravity.TOP;
                layoutParams.gravity = Gravity.TOP;
                snackbar.getView().setLayoutParams(layoutParams);
                snackbar.show();
            }
        });

        return linearLayout;
    }

}
