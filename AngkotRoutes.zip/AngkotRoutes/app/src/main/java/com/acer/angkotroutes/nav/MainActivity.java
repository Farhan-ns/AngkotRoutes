package com.acer.angkotroutes.nav;

import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;

import com.acer.angkotroutes.R;
import com.acer.angkotroutes.util.JSONParser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    Toolbar toolbar;
    BottomNavigationView bottomNav;
    BottomSheetBehavior bottomSheet;
    Fragment fragment;

    int stateExpanded = BottomSheetBehavior.STATE_EXPANDED;
    int stateCollapsed = BottomSheetBehavior.STATE_COLLAPSED;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        toolbar = findViewById(R.id.view_toolbar);
        String js = JSONParser.get(this, R.raw.data_angkot);
        String str = "";
        try {
            JSONArray jsra = new JSONArray(js);
            JSONObject jso = jsra.getJSONObject(0);
            str = jso.getString("nama_jurusan");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        toolbar.setTitle(str);
        setSupportActionBar(toolbar);

        bottomNav = findViewById(R.id.view_bottom_navigation);
        bottomNav.setOnNavigationItemSelectedListener(new BottomNavListener());

        FloatingActionButton fabRoutes = findViewById(R.id.fab_show_routes);
        fabRoutes.setOnClickListener(new FABListener());

        fragment = getSupportFragmentManager().findFragmentById(R.id.fragment_show_routes);

        View coordinatorLayout = findViewById(R.id.fragment_show_routes);
        bottomSheet = BottomSheetBehavior.from(coordinatorLayout);
        bottomSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
    }

    @Override
    public void onBackPressed() {
        if (bottomSheet.getState() == stateExpanded) {
            collapseBottomSheet();
        } else {
            super.onBackPressed();
        }
    }

    private void expandBottomSheet() { bottomSheet.setState(stateExpanded); }
    private void collapseBottomSheet() { bottomSheet.setState(stateCollapsed); }

    private class BottomNavListener implements BottomNavigationView.OnNavigationItemSelectedListener {
        @Override
        public boolean onNavigationItemSelected(MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_favorite:
                    toolbar.setTitle("Favorite");
                    return true;
                case R.id.navigation_maps:
                    toolbar.setTitle("Maps");
                    return true;
                case R.id.navigation_recent:
                    toolbar.setTitle("Recent");
                    return true;
            }
            return false;
        }
    }

    private class FABListener implements FloatingActionButton.OnClickListener {

        @Override
        public void onClick(View v) {
            if (bottomSheet.getState() == stateExpanded) {
                collapseBottomSheet();
            } else {
                expandBottomSheet();
            }
        }
    }

}
