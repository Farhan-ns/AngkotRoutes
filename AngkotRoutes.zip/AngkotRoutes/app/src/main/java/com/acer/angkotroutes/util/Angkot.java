package com.acer.angkotroutes.util;

public class Angkot {
    public static String texts[] = {"ANGKOT 1",
            "ANGKOT 2",
            "ANGKOT 3",
            "ANGKOT 4",
            "ANGKOT 5",
            "ANGKOT 6",
            "ANGKOT 7",
            "ANGKOT 8"};
}
