package com.acer.angkotroutes.nav;

import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.acer.angkotroutes.R;
import com.acer.angkotroutes.component.AngkotRoutesAdapter;

public class TestActivity extends AppCompatActivity {
    private String texts[] = {"ANGKOT 1", "ANGKOT 2", "ANGKOT 3", "ANGKOT 4", "ANGKOT 5", "ANGKOT 6", "ANGKOT 7", "ANGKOT 8"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        RecyclerView recyclerView = findViewById(R.id.recycler_view);
        final AngkotRoutesAdapter adapter = new AngkotRoutesAdapter(texts);

        recyclerView.setAdapter(adapter);

        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);

        adapter.setListener(new AngkotRoutesAdapter.Listener() {
            @Override
            public void onClick(int position) {
                int pos = position + 1;
                CharSequence sequence = "Card " + pos + " Clicked";
                Snackbar snackbar = Snackbar.make(findViewById(R.id.recycler_view), sequence, Snackbar.LENGTH_SHORT);
                snackbar.show();
            }
        });
    }
}
